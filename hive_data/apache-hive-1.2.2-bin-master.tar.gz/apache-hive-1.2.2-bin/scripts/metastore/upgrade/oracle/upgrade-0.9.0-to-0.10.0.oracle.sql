SELECT 'Upgrading MetaStore schema from 0.9.0 to 0.10.0' AS Status from dual;
@010-HIVE-3072.oracle.sql
@011-HIVE-3649.oracle.sql
@012-HIVE-1362.oracle.sql
SELECT 'Finished upgrading MetaStore schema from 0.9.0 to 0.10.0' AS Status from dual;
